import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class ServerAforismi { final static String gruppo = "224.0.0.1";
    final static int portaMulticast = 6789;
    final static int ritardo = 8000;  // ms
    final static String[] aforismi = {"L'istruzione è l'arma più potente che noi possiamo usare per cambiare il mondo (Nelson Mandela)",
            "Tutto quello che puoi fare, o sognare di poter fare, incomincialo. Il coraggio ha in            sé genio, potere e magia. Incomincia adesso. (Goethe)",
            "Il mondo è un bel posto, per il quale vale la pena di lottare. (Ernest Hemingway)",
            "La ragione e il torto non si dividono mai con un taglio così netto che ogni parte abbia soltanto dell'uno e dell'altra... (Alessandro Manzoni)",
            "Due cose sono infinite: l'universo e la stupidità umana, ma riguardo l'universo ho            ancora dei dubbi. (Albert Einstein)",
            "La natura è il miglior modo per comprendere l'arte; i pittori ci insegnano a vedere... (Vincent Van Gogh)"
    };
    public static void main(String[] args) {
        byte[] bufferOut;
        int indice = 0;
        try (MulticastSocket sck = new MulticastSocket()) {
            System.out.println("Server avviato.");
            InetAddress ipMulticast = InetAddress.getByName(gruppo);
            while(true) {
                Thread.sleep(ritardo);
                String af = aforismi[indice] + System.lineSeparator();
                bufferOut = af.getBytes("UTF-8");
                DatagramPacket pktOut = new DatagramPacket(bufferOut, bufferOut.length,ipMulticast, portaMulticast);

                sck.send(pktOut);
                System.out.format("Inviato l'aforisma n. %d all'indirizzo di multicast %s%n",indice, ipMulticast);
                indice = (indice + 1) % aforismi.length;
            }
        } catch (IOException e) {e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
