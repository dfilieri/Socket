import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class ClientAforismi {
    final static String gruppo = "225.6.7.8";
    final static int portaMulticast = 6789;
    final static int maxAforismi = 6;
    public static void main(String[] args) {
        try (MulticastSocket sck = new MulticastSocket(portaMulticast)) {
            System.out.println("Client avviato.");
            InetAddress ipMulticast = InetAddress.getByName(gruppo);
            sck.joinGroup(ipMulticast);
            try {
                for (int i = 1; i <= maxAforismi; i++) {
                    byte[] bufferIn = new byte[1024];
                    DatagramPacket pktIn = new DatagramPacket(bufferIn, bufferIn.length);
                    sck.receive(pktIn);
                    System.out.format("Aforisma n. %d/%d: ", i, maxAforismi);
                    String af = new String(pktIn.getData(), 0, pktIn.getLength(), "UTF-8");
                    System.out.print(af);
                }
            } finally {
                sck.leaveGroup(ipMulticast);
            }
        } catch (IOException e) {e.printStackTrace();
        }
    }
}
