import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ParallelServer implements Runnable{
    private Socket client;
    public ParallelServer (Socket client){
        this.client = client;
    }

    public void run(){
        try{
            // Ricava lo stream di output associate al socket
            // e definisce una classe wrapper di tipo
            // BufferedWriter per semplificare le operazioni
            // di scrittura
            OutputStream s1out = client.getOutputStream();
            BufferedWriter bw = new BufferedWriter(
                    new OutputStreamWriter(s1out));

            // Il server invia la risposta al client
            bw.write("Benvenuto sul server Multi-Client!");

            // Chiude lo stream di output e la connessione
            bw.close();
            client.close();
            System.out.println("Chiusura connessione effettuata");
        } catch (IOException ex){
            ex.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public static void main (String args[]){
        SimpleServer ss = new SimpleServer(7777);
        ss.runServer();
    }
}