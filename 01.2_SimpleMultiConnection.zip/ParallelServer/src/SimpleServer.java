import java.net.*;
import java.io.*;

public class SimpleServer {
    private int port;
    private ServerSocket server;
    private Socket client;

    public SimpleServer(int port) {
        this.port = port;
        if (!startServer())
            System.err.println("Errore durate la creazione del Server");
    }

    private boolean startServer() {
        try {
            server = new ServerSocket(port);
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
        System.out.println("Server creato con successo!");
        return true;
    }

    public void runServer() {
        while (true) {
            try {
                // Il server resta in attesa di una richiesta
                System.out.println("Server in attesa di richieste...");
                client = server.accept();
                System.out.println("Un client si e' connesso...");
                ParallelServer pServer = new ParallelServer(client);
                Thread t = new Thread(pServer);
                t.start();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}